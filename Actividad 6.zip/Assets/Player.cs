using UnityEngine;
using UnityEngine.AI;
[RequireComponent(typeof(NavMeshAgent))] // Automatically add NavMeshAgent component to the GameObject
public class Player : MonoBehaviour
{
    [SerializeField] LayerMask groundMask;

    InputSystem_Actions input;
    NavMeshAgent agent;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
   private void OnEnable()
    {
        input.Player.Enable();
    }

    private void OnDisable()
    {
        input.Player.Disable();
    }

    private void Awake()
    {
        input = new();
    }

    private void Start()
    {
        agent = GetComponent<NavMeshAgent>();
        input.Player.Click.performed += ctx =>
        {
    
          Ray ray = Camera.main.ScreenPointToRay(input.Player.Point.ReadValue<Vector2>());  
        if (Physics.Raycast(ray, out RaycastHit hit, Mathf.Infinity, groundMask))
        {
            agent.destination = hit.point;
        }
        
    };
    }
}
